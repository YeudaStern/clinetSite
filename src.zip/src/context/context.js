import React, { createContext } from 'react'


const MyStore = createContext()

export default MyStore;
