// const MAIN_ROUTE = "mongodb+srv://yeudaShtern:206261448@cluster0.sm6fiys.mongodb.net/design1/"
const MAIN_ROUTE = 'http://localhost:3002/'

const LOGIN_ROUTE = MAIN_ROUTE + "users/login"

const SIGNUP_ROUTE = MAIN_ROUTE + "users/signUp"

const FILE_UPLOAD = MAIN_ROUTE + "files/upload"

export { MAIN_ROUTE, SIGNUP_ROUTE, LOGIN_ROUTE, FILE_UPLOAD }