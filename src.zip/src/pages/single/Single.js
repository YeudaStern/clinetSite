import React from "react"
import "./single.scss"

export default function Single() {
  return (
    <div>Single Search user</div>
  )
}
