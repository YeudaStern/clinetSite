import React from "react"
import "./new.scss"

export default function New() {
  return (
    <div>Add new user</div>
  )
}
